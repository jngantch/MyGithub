import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


@SuppressWarnings("unused")
public class TownGraphTestSTUDENT {
	private GraphInterface<Town,Road> graph;
	private Town[] town;

	@Before
	public void setUp() throws Exception {
		 graph = new TownGraph();
		  town = new Town[12];
		  
		  for (int i = 1; i < 12; i++) {
			  town[i] = new Town("Town_" + i);
			  graph.addVertex(town[i]);
		  }
		  
		  graph.addEdge(town[1], town[2], 2, "Road_1");
		  graph.addEdge(town[1], town[3], 4, "Road_2");
		  graph.addEdge(town[1], town[5], 6, "Road_3");
		  graph.addEdge(town[3], town[6], 3, "Road_4");
		  graph.addEdge(town[3], town[5], 2, "Road_5");
		  graph.addEdge(town[4], town[5], 5, "Road_6");
		  graph.addEdge(town[2], town[4], 7, "Road_7");
		  graph.addEdge(town[9], town[10], 4, "Road_8");
		  graph.addEdge(town[8], town[10], 2, "Road_9");
		  graph.addEdge(town[5], town[10], 5, "Road_10");
		  graph.addEdge(town[10], town[11], 3, "Road_11");
		  graph.addEdge(town[2], town[11], 6, "Road_12");
	}

	@After
	public void tearDown() throws Exception {
		graph = null;
	}

	@Test
	public void testGetEdge_STUDENT() {
		assertEquals(new Road(town[4], town[5],5, "Road_6"), graph.getEdge(town[4], town[5]));
		assertEquals(new Road(town[1], town[5],6, "Road_3"), graph.getEdge(town[1], town[5]));
	}

	@Test
	public void testAddEdge_STUDENT() {
		assertEquals(false, graph.containsEdge(town[3], town[4]));
		graph.addEdge(town[3], town[4], 3, "Road_8");
		assertEquals(true, graph.containsEdge(town[3], town[4]));
	}

	@Test
	public void testAddVertex_STUDENT() {
		Town newTown = new Town("Town_5");
		assertEquals(true, graph.containsVertex(newTown));
		graph.addVertex(newTown);
		assertEquals(true, graph.containsVertex(newTown));
	}

	@Test
	public void testContainsEdge_STUDENT() {
		assertEquals(true, graph.containsEdge(town[2], town[4]));
		assertEquals(false, graph.containsEdge(town[2], town[5]));
	}

	@Test
	public void testContainsVertex_STUDENT() {
		assertEquals(true, graph.containsVertex(new Town("Town_2")));
		assertEquals(true, graph.containsVertex(new Town("Town_11")));
	}

	@Test
	public void testEdgeSet_STUDENT() {
		Set<Road> roads = graph.edgeSet();
		ArrayList<String> roadArrayList = new ArrayList<String>();
		for(Road road : roads)
			roadArrayList.add(road.getName());
		Collections.sort(roadArrayList);
		assertEquals("Road_1", roadArrayList.get(0));
		assertEquals("Road_10", roadArrayList.get(1));
		assertEquals("Road_11", roadArrayList.get(2));
		assertEquals("Road_12", roadArrayList.get(3));
		assertEquals("Road_2", roadArrayList.get(4));
		assertEquals("Road_3", roadArrayList.get(5));
	}

	@Test
	/*public void testEdgesOf() {
		Set<Road> roads = graph.edgesOf(town[1]);
		ArrayList<String> roadArrayList = new ArrayList<String>();
		for(Road road : roads)
			roadArrayList.add(road.getName());
		Collections.sort(roadArrayList);
		assertEquals("Road_1", roadArrayList.get(0));
		assertEquals("Road_2", roadArrayList.get(1));
		assertEquals("Road_3", roadArrayList.get(2));
	}
	
	@Test*/
	public void testEdgesOfSTUDENT() {
		Set<Road> roadss = graph.edgesOf(town[1]);
		ArrayList<String> roadAList = new ArrayList<String>();
		for(Road road : roadss)
			roadAList.add(road.getName());
		Collections.sort(roadAList);
		assertEquals("Road_1", roadAList.get(0));
		assertEquals("Road_2", roadAList.get(1));
		assertEquals("Road_3", roadAList.get(2));
		//fail("Test not implemented yet");
	}

	/*@Test
	public void testRemoveEdge() {
		assertEquals(true, graph.containsEdge(town[2], town[11]));
		graph.removeEdge(town[2], town[11], 6, "Road_12");
		assertEquals(false, graph.containsEdge(town[2], town[11]));
	}*/

	@Test
	public void testRemoveEdgeSTUDENT() {
		assertEquals(true, graph.containsEdge(town[2], town[4]));
		graph.removeEdge(town[2], town[4], 7, "Road_7");
		assertEquals(false, graph.containsEdge(town[2], town[4]));	
		//fail("Test not implemented yet");
	}
	
	@Test
	public void testRemoveVertex_STUDENT (){
		assertEquals(true, graph.containsVertex(town[3]));
		graph.removeVertex(town[3]);
		assertEquals(false, graph.containsVertex(town[3]));
	}

	@Test
	public void testVertexSet_STUDENT() {
		Set<Town> roads = graph.vertexSet();
		assertEquals(true,roads.contains(town[1]));
		assertEquals(true, roads.contains(town[2]));
		assertEquals(true, roads.contains(town[6]));
		assertEquals(true, roads.contains(town[3]));
		assertEquals(true, roads.contains(town[5]));
	}

	 @Test
	  public void testTown_1ToTown_6() {
		  String beginTown = "Town_1", endTown = "Town_6";
		  Town beginIndex=null, endIndex=null;
		  Set<Town> towns = graph.vertexSet();
		  Iterator<Town> iterator = towns.iterator();
		  while(iterator.hasNext())
		  {    	
			  Town town = iterator.next();
			  if(town.getName().equals(beginTown))
				  beginIndex = town;
			  if(town.getName().equals(endTown))
				  endIndex = town;		
		  }
		  if(beginIndex != null && endIndex != null)
		  {

			  ArrayList<String> path = graph.shortestPath(beginIndex,endIndex);
			  assertNotNull(path);
			  assertTrue(path.size() > 0);
			  assertEquals("Town_1 via Road_2 to Town_3 4 mi",path.get(0).trim());
			  assertEquals("Town_3 via Road_4 to Town_6 3 mi",path.get(1).trim());
		  }
		  else
			  fail("Town names are not valid");

	  }
	  
	  
	 /* @Test
	  public void testTown1ToTown_10_STUDENT() {
		  String beginTown = "Town_1", endTown = "Town_10";
		  Town beginIndex=null, endIndex=null;
		  Set<Town> towns = graph.vertexSet();
		  Iterator<Town> iterator = towns.iterator();
		  while(iterator.hasNext())
		  {    	
			  Town town = iterator.next();
			  if(town.getName().equals(beginTown))
				  beginIndex = town;
			  if(town.getName().equals(endTown))
				  endIndex = town;		
		  }
		  if(beginIndex != null && endIndex != null)
		  {

			  ArrayList<String> path = graph.shortestPath(beginIndex,endIndex);
			  assertNotNull(path);
			  assertTrue(path.size() > 0);
			  assertEquals("Town_1 via Road_2 to Town_3 4 mi",path.get(0).trim());
			  assertEquals("Town_3 via Road_5 to Town_8 2 mi",path.get(1).trim());
			  assertEquals("Town_8 via Road_9 to Town_10 2 mi",path.get(2).trim());
		  }
		  else
			  fail("Town names are not valid");

	  }
	  */
	  @Test
	  public void testTown_2ToTown_6_STUDENT() {
		  String beginTown = "Town_4", endTown = "Town_6";
		  Town beginIndex=null, endIndex=null;
		  Set<Town> towns = graph.vertexSet();
		  Iterator<Town> iterator = towns.iterator();
		  while(iterator.hasNext())
		  {    	
			  Town town = iterator.next();
			  if(town.getName().equals(beginTown))
				  beginIndex = town;
			  if(town.getName().equals(endTown))
				  endIndex = town;		
		  }
		  if(beginIndex != null && endIndex != null)
		  {

			  ArrayList<String> path = graph.shortestPath(beginIndex,endIndex);
			  assertNotNull(path);
			  assertTrue(path.size() > 0);
			  assertEquals("Town_4 via Road_6 to Town_5 5 mi",path.get(0).trim());
			  assertEquals("Town_5 via Road_5 to Town_3 2 mi",path.get(1).trim());
			  assertEquals("Town_3 via Road_4 to Town_6 3 mi",path.get(2).trim());
		  }
		  else
			  fail("Town names are not valid");

	  }
	 /* @Test
	  public void testTown_5ToTown_2STUDENT() {
		  ArrayList<String> path = graph.shortestPath(town[1],town[6]);
		  assertNotNull(path);
		  assertTrue(path.size() > 0);
		  assertEquals("Town_1 via Road_2 to Town_3 4 mi",path.get(0).trim());
		  assertEquals("Town_3 via Road_5 to Town_8 2 mi",path.get(1).trim());
		  assertEquals("Town_8 via Road_9 to Town_10 2 mi",path.get(2).trim());
		  assertEquals("Town_10 via Road_8 to Town_9 4 mi",path.get(3).trim());
		  assertEquals("Town_9 via Road_7 to Town_6 3 mi",path.get(4).trim());
		  //fail("Test not implemented yet");
	  }	*/
}